from tensorflow.keras import layers, models, optimizers
from config import LEARNING_RATE, INPUT_LEN


def res_block(x, filters):
    shortcut = layers.Conv1D(filters, 1, padding="same")(x)
    y = layers.Conv1D(filters, 5, padding="same", use_bias=False)(x)
    y = layers.BatchNormalization(momentum=0.9)(y)
    y = layers.ReLU()(y)
    y = layers.Conv1D(filters, 5, padding="same", use_bias=False)(y)
    y = layers.BatchNormalization(momentum=0.9)(y)
    y = layers.ReLU()(layers.Add()([shortcut, y]))
    return layers.MaxPooling1D(2)(y)


def build_model(n_classes, length=INPUT_LEN):
    inp = layers.Input((length, 1))
    x = layers.GaussianNoise(0.02)(inp)
    x = layers.Conv1D(32, 7, padding="same", use_bias=False)(x)
    x = layers.BatchNormalization(momentum=0.9)(x)
    x = layers.ReLU()(x)
    for f in (32, 64, 128):
        x = res_block(x, f)
    x = layers.Concatenate()([layers.GlobalAveragePooling1D()(x),
                              layers.GlobalMaxPooling1D()(x)])
    x = layers.Dropout(0.4)(x)
    x = layers.Dense(64, activation="relu")(x)
    x = layers.Dropout(0.3)(x)
    out = layers.Dense(n_classes, activation="softmax")(x)

    model = models.Model(inp, out)
    model.compile(optimizers.Adam(LEARNING_RATE),
                  "sparse_categorical_crossentropy", metrics=["accuracy"])
    return model
