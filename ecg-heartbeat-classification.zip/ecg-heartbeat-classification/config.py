from pathlib import Path

DATASET_DIR = Path(r"data")
OUT_DIR = DATASET_DIR / "Outputs_v2"
OUT_DIR.mkdir(parents=True, exist_ok=True)

SEED = 42
EPOCHS = 60
BATCH_SIZE = 64
LEARNING_RATE = 1e-3

# Use only the first INPUT_LEN samples of each beat (QRS, ST, T and P waves).
# The end of a dataset row (second R-peak + tail) differs by class in how rows were cut,
# so the model could "read" the cut instead of the heartbeat. It cannot be reproduced from images.
INPUT_LEN = 80
ROUNDTRIP_IMAGES = 1500   # synthetic images rendered + re-read for training (0 = off)
