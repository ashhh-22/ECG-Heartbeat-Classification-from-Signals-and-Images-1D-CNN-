import os
import sys
import logging
from pathlib import Path

os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"
logging.getLogger("tensorflow").setLevel(logging.ERROR)

import matplotlib.pyplot as plt
from tensorflow.keras.models import load_model
from config import OUT_DIR, INPUT_LEN
from digitize import analyze_image

IMAGE_PATH = r"data"   # <- your image
CROP = None    # optional (left, top, right, bottom) pixels to isolate ONE lead of a 12-lead page
TASK = "ptb"

NAMES = {
    "ptb": ["Normal", "Abnormal"],
    "mit": ["N - Normal", "S - Supraventricular", "V - Ventricular", "F - Fusion", "Q - Unknown"],
}
MEANING = {
    "Normal": "Beat shape matches normal ECG recordings",
    "Abnormal": "Beat shape matches abnormal (cardiac disease) recordings",
    "N - Normal": "Normal beat",
    "S - Supraventricular": "Supraventricular ectopic beat (arises above the ventricles)",
    "V - Ventricular": "Ventricular ectopic beat (premature ventricular contraction)",
    "F - Fusion": "Fusion of a normal and a ventricular beat",
    "Q - Unknown": "Unclassifiable beat",
}


def rate_label(bpm):
    return "Bradycardia (slow)" if bpm < 60 else "Tachycardia (fast)" if bpm > 100 else "Normal rate"


def main(image_path, task=TASK, crop=CROP):
    model = load_model(str(OUT_DIR / f"{task}_model.keras"), compile=False)
    r = analyze_image(image_path, crop=crop)
    probs = model.predict(r["beats"][:, :INPUT_LEN], verbose=0).mean(axis=0)
    names = NAMES[task]
    k = int(probs.argmax())

    line = "=" * 56
    print(f"\n{line}\n ECG RESULT\n{line}")
    print(f" Image          : {Path(image_path).name}")
    print(f" Beats analysed : {len(r['beats'])}  (strip {r['strip']} of {r['n_strips']})")
    print(f" Prediction     : {names[k]}  ({probs[k] * 100:.1f}%)")
    print(f" Meaning        : {MEANING[names[k]]}")
    if r["bpm"]:
        print(f" Heart rate     : ~{r['bpm']:.0f} bpm -> {rate_label(r['bpm'])}  (assumes 25 mm/s)")
    print(f"{line}\n Research prototype, not a medical diagnosis.\n{line}")

    plt.figure(figsize=(12, 3))
    plt.plot(r["sig"], lw=1)
    plt.plot(r["peaks"], r["sig"][r["peaks"]], "rx", label="R-peaks")
    plt.title(f"Digitised strip {r['strip']} -> {names[k]}")
    plt.legend()
    plt.savefig(OUT_DIR / "digitised_check.png", dpi=200, bbox_inches="tight")
    plt.close()


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else IMAGE_PATH
    task = sys.argv[2] if len(sys.argv) > 2 else TASK
    main(path, task)
