import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import (classification_report, confusion_matrix,
                             balanced_accuracy_score, roc_auc_score, roc_curve)
from config import OUT_DIR


def youden_threshold(y, p):
    fpr, tpr, thr = roc_curve(y, p)
    return float(thr[np.argmax(tpr - fpr)])


def report(model, X, y, names, tag, threshold=None):
    prob = model.predict(X, batch_size=512, verbose=0)
    pred = prob.argmax(1) if threshold is None else (prob[:, 1] >= threshold).astype(int)

    auc = (roc_auc_score(y, prob[:, 1]) if len(names) == 2
           else roc_auc_score(y, prob, multi_class="ovr", average="macro"))
    print(f"\n=== {tag} ===")
    print(classification_report(y, pred, target_names=names, digits=3))
    print(f"Balanced accuracy: {balanced_accuracy_score(y, pred):.4f} | ROC-AUC: {auc:.4f}")

    plt.figure(figsize=(6, 5))
    sns.heatmap(confusion_matrix(y, pred, normalize="true"), annot=True, fmt=".2f",
                cmap="Blues", vmin=0, vmax=1, xticklabels=names, yticklabels=names)
    plt.xlabel("Predicted"); plt.ylabel("Actual"); plt.title(tag)
    plt.savefig(OUT_DIR / f"{tag}_confusion.png", dpi=200, bbox_inches="tight")
    plt.close()
