"""Render training beats as ECG images (random grid colour, resolution, pen width, JPEG) and
read them back with the real digitiser, so the model also trains on beats exactly as they
come out of an image."""
import tempfile
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from PIL import Image
from scipy.signal import find_peaks
from config import INPUT_LEN
from digitize import analyze_image

GRIDS = [("#f6c9c9", "#e59a9a"), ("#f2c4c4", "#d97b7b"), ("#dddddd", "#b5b5b5"),
         ("#d6ead0", "#a6cf93"), (None, None)]                 # pink, red, gray, green, none
BACKGROUNDS = ["white", "#fffdf5", "#fbf7ee"]


def trim(row):
    """Row without zero padding and without the next beat's R-peak it carries at its end."""
    nz = np.flatnonzero(row > 0)
    b = row[: nz[-1] + 1]
    pk = find_peaks(b, height=0.6)[0]
    return b[: pk[-1] - 3] if len(pk) and pk[-1] > 20 else b


def render(sig, rng, path, fs=125):
    """Draw `sig` at 25 mm/s with a random look and save it as PNG or JPEG."""
    minor, major = GRIDS[rng.integers(len(GRIDS))]
    bg = BACKGROUNDS[rng.integers(len(BACKGROUNDS))]
    dpi, lw = int(rng.integers(70, 201)), float(rng.uniform(0.8, 2.2))
    t = np.arange(len(sig)) / fs
    T, h_mm = t[-1], float(rng.uniform(30, 60))
    fig = plt.figure(figsize=(T * 25 / 25.4, h_mm / 25.4), dpi=dpi, facecolor=bg)
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, T)
    ax.set_ylim(-0.3, 1.3)
    ax.axis("off")
    if minor:
        for x in np.arange(0, T, 0.04):
            ax.axvline(x, color=minor, lw=0.5)
        for y in np.arange(-0.3, 1.3, 1.6 * 1 / h_mm * 1.0 * 25 / 25 * 1):   # 1 mm
            ax.axhline(y, color=minor, lw=0.5)
        for x in np.arange(0, T, 0.2):
            ax.axvline(x, color=major, lw=0.9)
        for y in np.arange(-0.3, 1.3, 1.6 * 5 / h_mm):                       # 5 mm
            ax.axhline(y, color=major, lw=0.9)
    ax.plot(t, sig, color="black", lw=lw)
    fig.savefig(path, dpi=dpi, facecolor=bg)
    plt.close(fig)
    if str(path).endswith(".jpg"):                              # re-save with JPEG artefacts
        Image.open(path).convert("RGB").save(path, quality=int(rng.integers(50, 96)))


def roundtrip(X, y, n_images, rng, beats_per_image=6):
    """X: (n, 187) full-length rows. Returns beats read back from rendered images + labels."""
    classes = np.unique(y)
    out_X, out_y = [], []
    with tempfile.TemporaryDirectory() as d:
        for i in range(n_images):
            c = classes[i % len(classes)]
            idx = rng.choice(np.flatnonzero(y == c), beats_per_image, replace=False)
            path = Path(d) / f"img{i}.{'jpg' if rng.random() < 0.5 else 'png'}"
            render(np.concatenate([trim(X[j]) for j in idx]), rng, path)
            try:
                beats = analyze_image(str(path))["beats"][:, :INPUT_LEN]
            except ValueError:
                continue
            out_X.append(beats)
            out_y.append(np.full(len(beats), c, np.int64))
    return np.concatenate(out_X), np.concatenate(out_y)
