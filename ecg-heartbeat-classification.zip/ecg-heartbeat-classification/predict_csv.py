import os
import sys

os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"

import numpy as np
import pandas as pd
from tensorflow.keras.models import load_model
from config import OUT_DIR, INPUT_LEN

CSV_PATH = r"data"   # <- your CSV (one beat per row, no header)
TASK = "ptb"

NAMES = {"ptb": ["Normal", "Abnormal"], "mit": ["N", "S", "V", "F", "Q"]}


def main(csv_path, task=TASK):
    names = NAMES[task]
    model = load_model(str(OUT_DIR / f"{task}_model.keras"), compile=False)

    X = pd.read_csv(csv_path, header=None).to_numpy(np.float32)
    truth = None
    if X.shape[1] == 188:                                       # last column = true label (as in the datasets)
        X, truth = X[:, :-1], X[:, -1].astype(int)
    if X.shape[1] < INPUT_LEN:
        raise ValueError(f"Need at least {INPUT_LEN} columns per beat, found {X.shape[1]}.")
    probs = model.predict(X[:, :INPUT_LEN, None], verbose=0)   # extra columns (e.g. label) are ignored
    pred = probs.argmax(1)

    out = pd.DataFrame({"beat": np.arange(len(X)), "prediction": [names[i] for i in pred],
                        "confidence": probs.max(1).round(3)})
    out.to_csv(OUT_DIR / "csv_predictions.csv", index=False)

    line = "=" * 48
    print(f"\n{line}\n CSV RESULT\n{line}")
    print(f" File   : {os.path.basename(csv_path)}")
    print(f" Beats  : {len(X)}")
    for i, n in enumerate(names):
        k = int((pred == i).sum())
        print(f" {n:<8}: {k}  ({100 * k / len(X):.1f}%)")
    if truth is not None:
        print(f"{line}\n Compared with the labels in the file:")
        print(f" Correct: {int((pred == truth).sum())} of {len(X)}  ({100 * (pred == truth).mean():.1f}%)")
        for i, n in enumerate(names):
            if (truth == i).any():
                print(f" {n:<8} found correctly: {100 * (pred[truth == i] == i).mean():.1f}%")
    print(f"{line}\n Per-beat results saved to:\n {OUT_DIR / 'csv_predictions.csv'}\n{line}")


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else CSV_PATH
    task = sys.argv[2] if len(sys.argv) > 2 else TASK
    main(path, task)
