import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from config import DATASET_DIR, SEED, INPUT_LEN


def load_csv(name):
    path = next(DATASET_DIR.rglob(name), None)
    if path is None:
        raise FileNotFoundError(f"{name} not found under {DATASET_DIR}")
    arr = pd.read_csv(path, header=None).to_numpy(np.float32)
    assert arr.shape[1] == 188 and np.isfinite(arr).all(), f"{name}: bad shape or values"
    return arr[:, :-1, None], arr[:, -1].astype(np.int64)   # full 187 columns


def _cut(splits, full):
    return tuple((X if full else X[:, :INPUT_LEN], y) for X, y in splits)


def load_ptbdb(full=False):
    Xn, yn = load_csv("ptbdb_normal.csv")
    Xa, ya = load_csv("ptbdb_abnormal.csv")
    assert np.unique(yn).tolist() == [0] and np.unique(ya).tolist() == [1]
    X, y = np.concatenate([Xn, Xa]), np.concatenate([yn, ya])
    X_tr, X_tmp, y_tr, y_tmp = train_test_split(X, y, test_size=0.30, stratify=y, random_state=SEED)
    X_val, X_te, y_val, y_te = train_test_split(X_tmp, y_tmp, test_size=0.50, stratify=y_tmp, random_state=SEED)
    return _cut([(X_tr, y_tr), (X_val, y_val), (X_te, y_te)], full)


def load_mitbih(full=False):
    X, y = load_csv("mitbih_train.csv")
    X_te, y_te = load_csv("mitbih_test.csv")
    X_tr, X_val, y_tr, y_val = train_test_split(X, y, test_size=0.15, stratify=y, random_state=SEED)
    return _cut([(X_tr, y_tr), (X_val, y_val), (X_te, y_te)], full)
