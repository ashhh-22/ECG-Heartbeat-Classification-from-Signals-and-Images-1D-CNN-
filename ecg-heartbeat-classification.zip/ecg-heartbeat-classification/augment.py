"""Training-time augmentation that mimics what reading a beat from an image does to it:
thick pen (blurred / widened peaks and valleys), noise, and small time-scale error."""
import numpy as np
from scipy.ndimage import maximum_filter1d, minimum_filter1d, uniform_filter1d
from tensorflow import keras


def augment(X, rng, keep_clean=0.25):
    """X: (n, L) beats scaled 0-1. Returns augmented copy; a share is left clean."""
    n, L = X.shape
    A = X.copy()
    f = rng.uniform(0.8, 1.25, n)                                   # time scale
    for i in range(n):
        A[i] = np.interp(np.arange(L) / f[i], np.arange(L), A[i])
    kind, width = rng.integers(0, 4, n), rng.integers(2, 6, n)     # kind 3 = no pen effect
    for k, fn in enumerate((uniform_filter1d, maximum_filter1d, minimum_filter1d)):
        for w in (2, 3, 4, 5):
            sel = (kind == k) & (width == w)
            if sel.any():
                A[sel] = fn(A[sel], size=w, axis=1)
    A += rng.normal(0, 1, A.shape) * rng.uniform(0, 0.02, (n, 1))  # noise
    lo, hi = A.min(1, keepdims=True), A.max(1, keepdims=True)
    A = (A - lo) / (hi - lo + 1e-8)
    return np.where(rng.random((n, 1)) < keep_clean, X, A).astype(np.float32)


class AugSeq(keras.utils.PyDataset):
    """Yields freshly augmented, class-weighted batches every epoch."""

    def __init__(self, X, y, class_weight, batch_size, seed=0, **kwargs):
        super().__init__(**kwargs)
        self.X, self.y = X[..., 0], y
        self.w = np.array([class_weight[int(c)] for c in y], np.float32)
        self.bs, self.rng = batch_size, np.random.default_rng(seed)
        self.order = self.rng.permutation(len(y))

    def __len__(self):
        return int(np.ceil(len(self.y) / self.bs))

    def __getitem__(self, i):
        idx = self.order[i * self.bs:(i + 1) * self.bs]
        return augment(self.X[idx], self.rng)[..., None], self.y[idx], self.w[idx]

    def on_epoch_end(self):
        self.order = self.rng.permutation(len(self.y))
