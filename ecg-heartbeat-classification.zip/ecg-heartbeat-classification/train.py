import sys
import numpy as np
import tensorflow as tf
from tensorflow.keras import callbacks
from sklearn.metrics import balanced_accuracy_score
from sklearn.utils.class_weight import compute_class_weight

from config import OUT_DIR, SEED, EPOCHS, BATCH_SIZE, ROUNDTRIP_IMAGES
from data import load_ptbdb, load_mitbih
from model import build_model
from evaluate import report, youden_threshold
from augment import AugSeq, augment
from synth import roundtrip

TASKS = {
    "ptb": (load_ptbdb, ["Normal", "Abnormal"]),
    "mit": (load_mitbih, ["N", "S", "V", "F", "Q"]),
}


class BalancedAcc(callbacks.Callback):
    """Adds val_bal_acc to the logs. Must come BEFORE the callbacks that monitor it."""
    def __init__(self, X, y):
        super().__init__()
        self.X, self.y = X, y

    def on_epoch_end(self, epoch, logs=None):
        pred = self.model.predict(self.X, batch_size=512, verbose=0).argmax(1)
        logs["val_bal_acc"] = balanced_accuracy_score(self.y, pred)


def main(task):
    tf.keras.utils.set_random_seed(SEED)
    load, names = TASKS[task]
    (X_tr, y_tr), (X_val, y_val), (X_te, y_te) = load()
    if ROUNDTRIP_IMAGES:   # add beats read back from rendered ECG images (cached after first run)
        cache = OUT_DIR / f"roundtrip_{task}.npz"
        if not cache.exists():
            rng = np.random.default_rng(SEED)
            (F_tr, fy_tr), (F_val, fy_val), _ = load(full=True)
            Xi, yi = roundtrip(F_tr[..., 0], fy_tr, ROUNDTRIP_IMAGES, rng)
            Xv, yv = roundtrip(F_val[..., 0], fy_val, ROUNDTRIP_IMAGES // 10, rng)
            np.savez(cache, Xi=Xi, yi=yi, Xv=Xv, yv=yv)
        z = np.load(cache)
        print("Image-derived beats added:", len(z["yi"]), "train,", len(z["yv"]), "validation")
        X_tr, y_tr = np.concatenate([X_tr, z["Xi"]]), np.concatenate([y_tr, z["yi"]])
        X_val, y_val = np.concatenate([X_val, z["Xv"]]), np.concatenate([y_val, z["yv"]])

    classes = np.unique(y_tr)
    weights = compute_class_weight("balanced", classes=classes, y=y_tr)
    class_weight = {int(c): float(w) for c, w in zip(classes, weights)}
    print("Class weights:", class_weight)

    # validation = clean beats + one fixed augmented copy, so the chosen epoch is robust
    X_aug = augment(X_val[..., 0], np.random.default_rng(SEED))[..., None]
    X_vm, y_vm = np.concatenate([X_val, X_aug]), np.concatenate([y_val, y_val])

    model = build_model(len(names))
    model.fit(
        AugSeq(X_tr, y_tr, class_weight, BATCH_SIZE, seed=SEED),
        validation_data=(X_vm, y_vm),
        epochs=EPOCHS, verbose=2,
        callbacks=[
            BalancedAcc(X_vm, y_vm),
            callbacks.ReduceLROnPlateau(monitor="val_bal_acc", mode="max",
                                        factor=0.5, patience=4, min_lr=1e-5),
            callbacks.EarlyStopping(monitor="val_bal_acc", mode="max", patience=12,
                                    restore_best_weights=True),
        ],
    )
    model.save(str(OUT_DIR / f"{task}_model.keras"))

    report(model, X_te, y_te, names, f"{task}_test_argmax")
    if len(names) == 2:  # threshold chosen on validation data only
        thr = youden_threshold(y_val, model.predict(X_val, verbose=0)[:, 1])
        print(f"\nValidation-selected threshold: {thr:.4f}")
        report(model, X_te, y_te, names, f"{task}_test_tuned", threshold=thr)


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "ptb")
