"""Exploratory data analysis of the ECG CSV files: summary table + plots in OUT_DIR/eda."""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.decomposition import PCA
from config import OUT_DIR, SEED
from data import load_csv

EDA_DIR = OUT_DIR / "eda"
EDA_DIR.mkdir(parents=True, exist_ok=True)
sns.set_theme(style="whitegrid")

FILES = {"MIT-BIH train": "mitbih_train.csv", "MIT-BIH test": "mitbih_test.csv",
         "PTBDB normal": "ptbdb_normal.csv", "PTBDB abnormal": "ptbdb_abnormal.csv"}
MIT = ["N", "S", "V", "F", "Q"]
PTB = ["Normal", "Abnormal"]


def used_length(X):
    """Samples before the zero padding starts (last non-zero index + 1)."""
    nz = X > 0
    return np.where(nz.any(1), X.shape[1] - np.argmax(nz[:, ::-1], axis=1), 0)


def save(name):
    plt.tight_layout()
    plt.savefig(EDA_DIR / name, dpi=200, bbox_inches="tight")
    plt.close()


def summary(data):
    rows = []
    for name, (X, y) in data.items():
        X = X[..., 0]
        rows.append({
            "dataset": name, "rows": len(X), "columns": X.shape[1] + 1,
            "missing": int(np.isnan(X).sum()),
            "duplicate_rows": int(pd.DataFrame(X).duplicated().sum()),
            "min": float(X.min()), "max": float(X.max()),
            "median_beat_length": int(np.median(used_length(X))),
            "class_counts": dict(zip(*np.unique(y, return_counts=True))),
        })
    df = pd.DataFrame(rows)
    df.to_csv(EDA_DIR / "dataset_summary.csv", index=False)
    print(df.to_string(index=False))


def plot_class_distribution(data):
    rows = [(n, str(c), int(k)) for n, (_, y) in data.items() for c, k in zip(*np.unique(y, return_counts=True))]
    df = pd.DataFrame(rows, columns=["Dataset", "Label", "Records"])
    sns.barplot(data=df, x="Dataset", y="Records", hue="Label")
    plt.title("Class distribution")
    plt.xticks(rotation=15)
    save("01_class_distribution.png")


def plot_examples(X, y, names, tag, n=3):
    fig, axes = plt.subplots(len(names), 1, figsize=(10, 2.2 * len(names)), sharex=True, squeeze=False)
    for c, ax in enumerate(axes[:, 0]):
        for i in np.flatnonzero(y == c)[:n]:
            ax.plot(X[i], lw=1)
        ax.set_ylabel(names[c])
    axes[-1, 0].set_xlabel("Sample (125 Hz)")
    fig.suptitle(f"{tag}: example beats per class")
    save(f"02_{tag}_examples.png")


def plot_mean_std(X, y, names, tag):
    t = np.arange(X.shape[1])
    for c, name in enumerate(names):
        m, s = X[y == c].mean(0), X[y == c].std(0)
        plt.plot(t, m, label=name)
        plt.fill_between(t, m - s, m + s, alpha=0.15)
    plt.title(f"{tag}: mean beat +/- 1 std per class")
    plt.xlabel("Sample (125 Hz)")
    plt.legend()
    save(f"03_{tag}_mean_std.png")


def plot_lengths(X, y, names, tag):
    """Beat length per class. If classes differ a lot, a model can learn the length, not the heart."""
    df = pd.DataFrame({"length": used_length(X), "class": [names[int(c)] for c in y]})
    sns.histplot(df, x="length", hue="class", bins=40, element="step", stat="density", common_norm=False)
    plt.title(f"{tag}: beat length before zero padding")
    save(f"04_{tag}_beat_length.png")


def plot_pca(X, y, names, tag, n=4000):
    idx = np.random.default_rng(SEED).choice(len(X), min(n, len(X)), replace=False)
    Z = PCA(2, random_state=SEED).fit_transform(X[idx])
    sns.scatterplot(x=Z[:, 0], y=Z[:, 1], hue=[names[int(c)] for c in y[idx]], s=8, linewidth=0)
    plt.title(f"{tag}: PCA of beats (class separability)")
    save(f"05_{tag}_pca.png")


def main():
    data = {n: load_csv(f) for n, f in FILES.items()}
    summary(data)
    plot_class_distribution(data)

    ptb_X = np.concatenate([data["PTBDB normal"][0], data["PTBDB abnormal"][0]])[..., 0]
    ptb_y = np.concatenate([data["PTBDB normal"][1], data["PTBDB abnormal"][1]])
    for tag, X, y, names in [("mitbih", data["MIT-BIH train"][0][..., 0], data["MIT-BIH train"][1], MIT),
                             ("ptbdb", ptb_X, ptb_y, PTB)]:
        plot_examples(X, y, names, tag)
        plot_mean_std(X, y, names, tag)
        plot_lengths(X, y, names, tag)
        plot_pca(X, y, names, tag)
    print("Saved to", EDA_DIR)


if __name__ == "__main__":
    main()
