"""Automatic ECG image -> heartbeat conversion. No manual crop needed."""
import numpy as np
from PIL import Image
from scipy.ndimage import binary_dilation, gaussian_filter1d
from scipy.signal import find_peaks

FS = 125         # sampling rate of the training beats (Hz)
LENGTH = 187     # training beat length (samples)
TAIL_SEC = 0.2   # time kept after the next R-peak (training rows carry a short tail)
STD_PPS = 110.0  # pixels per second that the pixel-based settings below are tuned for


def _otsu(values, bins=64):
    hist, edges = np.histogram(values, bins=bins, range=(0, 1))
    centers = (edges[:-1] + edges[1:]) / 2
    p = hist / max(hist.sum(), 1)
    w, mu = np.cumsum(p), np.cumsum(p * centers)
    return float(centers[np.argmax((mu[-1] * w - mu) ** 2 / (w * (1 - w) + 1e-12))])


def _gray(img):
    return np.asarray(img, np.float32) @ np.array([0.299, 0.587, 0.114], np.float32) / 255


def grid_pps(gray, mask=None, mm_per_sec=25):
    """Pixels per second from the paper grid (large box = 5 mm = 0.2 s).
    Returns (pps, strength) or (None, 0) when no clear grid is present."""
    bg = np.median(gray)
    g = gray.copy()
    g[mask if mask is not None else gray < 0.4] = bg      # remove the dark trace, keep the grid
    col = 1 - g.mean(axis=0)
    col -= col.mean()
    n = len(col)
    ac = np.correlate(col, col, "full")[n - 1:]
    ac = ac / (ac[0] + 1e-12)
    pk = find_peaks(ac[: n // 2], prominence=0.05)[0]
    pk = pk[pk >= 3]
    if len(pk) == 0:
        return None, 0.0
    s = int(pk[0])
    cand = pk[(pk >= 4.4 * s) & (pk <= 5.6 * s)]       # 5 small boxes = 1 large box
    large = int(cand[np.argmax(ac[cand])]) if len(cand) and ac[cand].max() >= ac[s] else s
    return large / (5 / mm_per_sec), float(ac[large])


def load_trace_mask(img):
    """Boolean mask of the dark trace. Uses the brightest colour channel, so red/pink/green
    grids vanish (bright in one channel) while the black trace stays dark in all of them."""
    v = np.asarray(img, np.float32).max(axis=2) / 255
    cand = v[v < np.median(v) - 0.1]                   # grid + trace pixels
    thr = _otsu(cand) if cand.size > 200 else 0.5      # 1st split: background vs grid+trace
    dark = v[v < thr]
    strong_thr = max(_otsu(dark), 0.25) if dark.size > 200 else thr
    strong, weak = v < strong_thr, v < thr
    # hysteresis: keep faint trace pixels only if they sit right next to a strong trace pixel,
    # so thin/broken traces are bridged but the lighter grid is not picked up
    mask = strong | (weak & binary_dilation(strong, structure=np.ones((3, 3)), iterations=3))
    mask[mask.mean(axis=1) > 0.9] = False              # grid lines spanning the whole image
    mask[:, mask.mean(axis=0) > 0.9] = False
    return mask


def find_strips(mask):
    """Locate each lead/rhythm strip by its baseline row. Returns [(baseline, top, bottom)]."""
    H, W = mask.shape
    prof = gaussian_filter1d(mask.sum(axis=1).astype(float), 3)
    cand, _ = find_peaks(prof, height=0.2 * prof.max(), distance=max(20, H // 10))
    # a real baseline has trace pixels across much of the width; T-wave bumps and text do not
    cover = [mask[max(0, r - 8): r + 9].any(axis=0).mean() for r in cand]
    peaks = np.array([r for r, c in zip(cand, cover) if c >= 0.4])
    if len(peaks) == 0:
        peaks = np.array([int(cand[np.argmax(cover)]) if len(cand) else int(np.argmax(prof))])
    edges = [0] + [(a + b) // 2 for a, b in zip(peaks[:-1], peaks[1:])] + [H]
    return [(int(p), edges[i], edges[i + 1]) for i, p in enumerate(peaks)]


def strip_signal(mask, base, top, bot, max_jump=45):
    """Follow the trace left to right: in each column take the dark run nearest the previous
    position (so other strips, text and grid remnants are ignored); spikes use the far end.
    If the trace is lost for 3 columns, re-acquire the nearest run anywhere in the strip."""
    sub = mask[top:bot]
    W = sub.shape[1]
    prev = float(base - top)
    rows_out = np.full(W, np.nan)
    miss = 0
    for c in range(W):
        rows = np.flatnonzero(sub[:, c])
        if rows.size == 0:
            miss += 1
            continue
        runs = np.split(rows, np.flatnonzero(np.diff(rows) > 7) + 1)
        dist = [0 if r[0] <= prev <= r[-1] else min(abs(r[0] - prev), abs(r[-1] - prev)) for r in runs]
        k = int(np.argmin(dist))
        if dist[k] > max_jump:
            miss += 1
            if miss < 3:
                continue
        miss = 0
        r = runs[k]
        prev = float(r[0] if abs(r[0] - prev) > abs(r[-1] - prev) else r[-1])
        rows_out[c] = prev
    ok = np.flatnonzero(~np.isnan(rows_out))
    if len(ok) < 0.3 * W:
        return None
    return -np.interp(np.arange(W), ok, rows_out[ok])


def find_r_peaks(sig, min_gap):
    """Return (signal with R-peaks pointing up, R-peak indices)."""
    x = sig - np.median(sig)
    if abs(x.min()) > abs(x.max()):
        x = -x
    edge = max(1, int(0.04 * len(x)))                  # ignore calibration pulse at the left edge
    x[:edge] = 0
    peaks, _ = find_peaks(x, prominence=0.55 * x.max(), distance=max(8, int(min_gap)))
    return x, peaks


def segment_beats(sig, peaks, px_per_sec):
    """R-peak -> next R-peak (+ short tail), resampled to 125 Hz in real time,
    scaled 0-1, zero-padded to 187 samples, like the training rows."""
    rr = np.diff(peaks)
    med = np.median(rr)
    beats = []
    for a, b, d in zip(peaks[:-1], peaks[1:], rr):
        if not 0.6 * med < d < 1.6 * med:              # drop wrong R-R (missed peak / lead change)
            continue
        seg = sig[a:min(len(sig), b + 1 + int(round(TAIL_SEC * px_per_sec)))]
        n = max(20, int(round(len(seg) / px_per_sec * FS)))
        seg = np.interp(np.linspace(0, len(seg) - 1, n), np.arange(len(seg)), seg)[:LENGTH]
        seg = (seg - seg.min()) / (seg.max() - seg.min() + 1e-8)
        beats.append(np.pad(seg, (0, LENGTH - len(seg))))
    return np.array(beats, np.float32)[..., None]


def analyze_image(path, crop=None):
    """Find the best strip in the image and return beats + heart rate (if a grid is found)."""
    img = Image.open(path).convert("RGB")
    if crop:
        img = img.crop(crop)
    pps0, strength = grid_pps(_gray(img))
    if pps0 and strength >= 0.25 and abs(STD_PPS / pps0 - 1) > 0.15:
        f = float(np.clip(STD_PPS / pps0, 0.25, 4))     # bring every image to a standard scale
        img = img.resize((max(1, round(img.width * f)), max(1, round(img.height * f))), Image.BILINEAR)
    gray = _gray(img)
    mask = load_trace_mask(img)
    pps_grid, strength = grid_pps(gray, mask)
    if strength < 0.25:
        pps_grid = None
    strips = find_strips(mask)
    best = None
    for k, (base, top, bot) in enumerate(strips):
        sig = strip_signal(mask, base, top, bot)
        if sig is None:
            continue
        pps = pps_grid or mask.shape[1] / 10          # fallback if no grid: assume width = 10 s
        sig, peaks = find_r_peaks(sig, 0.25 * pps)
        if len(peaks) < 2:
            continue
        rr_med = float(np.median(np.diff(peaks)))
        use_grid = pps_grid is not None and 20 <= 60 * pps_grid / rr_med <= 220   # plausible rate?
        if not use_grid:                               # no usable grid: assume median R-R = 0.8 s
            pps = rr_med / 0.8
        beats = segment_beats(sig, peaks, pps)
        if len(beats) and (best is None or len(beats) > len(best["beats"])):
            bpm = 60 * pps / rr_med if use_grid else None
            best = dict(beats=beats, sig=sig, peaks=peaks, bpm=bpm, strip=k + 1, n_strips=len(strips))
    if best is None:
        raise ValueError("No heartbeats found: need a clear trace with at least 2 beats.")
    return best
