"""Clean the ECG beats before training: drop duplicates, flat rows and out-of-range rows.
Writes cleaned_<task>.npz and a before/after report + plot to OUT_DIR/eda."""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from config import OUT_DIR
from data import load_csv

EDA_DIR = OUT_DIR / "eda"
EDA_DIR.mkdir(parents=True, exist_ok=True)


def clean(X, y):
    """X: (n, 187). Returns cleaned X, y and a dict counting what was removed."""
    flat = (X.max(1) - X.min(1)) < 0.05                       # no real waveform
    out_of_range = (X.min(1) < -0.01) | (X.max(1) > 1.01)     # not scaled 0-1
    dup = pd.DataFrame(X).duplicated().to_numpy()             # identical rows (leak across splits)
    keep = ~(flat | out_of_range | dup)
    report = {"before": len(X), "flat": int(flat.sum()), "out_of_range": int(out_of_range.sum()),
              "duplicates": int(dup.sum()), "after": int(keep.sum())}
    return X[keep], y[keep], report


def load_tasks():
    mit_X, mit_y = load_csv("mitbih_train.csv")
    mit_Xt, mit_yt = load_csv("mitbih_test.csv")
    Xn, yn = load_csv("ptbdb_normal.csv")
    Xa, ya = load_csv("ptbdb_abnormal.csv")
    return {"mitbih_train": (mit_X[..., 0], mit_y), "mitbih_test": (mit_Xt[..., 0], mit_yt),
            "ptbdb": (np.concatenate([Xn, Xa])[..., 0], np.concatenate([yn, ya]))}


def main():
    rows, counts = [], []
    for task, (X, y) in load_tasks().items():
        Xc, yc, rep = clean(X, y)
        rows.append({"task": task, **rep})
        for stage, labels in (("before", y), ("after", yc)):
            for c, k in zip(*np.unique(labels, return_counts=True)):
                counts.append({"task": task, "stage": stage, "label": str(c), "records": int(k)})
        np.savez_compressed(OUT_DIR / f"cleaned_{task}.npz", X=Xc, y=yc)
    report = pd.DataFrame(rows)
    report.to_csv(EDA_DIR / "preprocess_report.csv", index=False)
    print(report.to_string(index=False))

    g = sns.catplot(data=pd.DataFrame(counts), x="label", y="records", hue="stage",
                    col="task", kind="bar", sharey=False, height=3.5)
    g.fig.suptitle("Class counts before / after cleaning", y=1.05)
    g.savefig(EDA_DIR / "06_preprocess_before_after.png", dpi=200, bbox_inches="tight")
    print("Saved to", OUT_DIR)


if __name__ == "__main__":
    main()
